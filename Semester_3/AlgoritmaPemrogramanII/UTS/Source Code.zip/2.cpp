#include <iostream>
using namespace std;

int main()
{
    cout << "\nMuhammad Mabi Palaka - 231011401691\n\n";
    int A, B, C, hasil;

    cout << "Masukkan nilai A: ";
    cin >> A;
    cout << "Masukkan nilai B: ";
    cin >> B;
    cout << "Masukkan nilai C: ";
    cin >> C;

    hasil = (A + B - C) * 2;

    cout << "Hasil dari (A + B - C) * 2 adalah: " << hasil << endl;

    return 0;
}
